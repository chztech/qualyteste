<?php
require_once '../config/cors.php';
require_once '../config/database.php';
require_once '../helpers/functions.php';

header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'PATCH') {
  jsonResponse(false, [], 405, 'Método não permitido');
}

try {
  $db = (new Database())->getConnection();
  $body = json_decode(file_get_contents('php://input'), true);
  if (json_last_error() !== JSON_ERROR_NONE) jsonResponse(false, [], 400, 'JSON inválido');

  $id = $body['id'] ?? null;
  if (!$id) jsonResponse(false, [], 422, 'id é obrigatório');

  // Campos que podem ser atualizados (snake_case)
  $allowed = [
    'date','start_time','end_time','duration','status','notes',
    'company_id','employee_id','provider_id','client_id','service_id','service_name'
  ];
  $sets = [];
  $params = [':id' => $id];

  foreach ($allowed as $col) {
    if (array_key_exists($col, $body)) {
      $sets[] = "$col = :$col";
      $params[":$col"] = $body[$col];
    }
  }

  if (!$sets) jsonResponse(false, [], 400, 'Nenhum campo para atualizar');

  $sql = "UPDATE appointments SET ".implode(', ', $sets).", updated_at = now()
          WHERE id = :id
          RETURNING id, company_id, employee_id, provider_id, client_id, service_id,
                    date, start_time, end_time, duration, status, service_name, notes,
                    created_at, updated_at";
  $stmt = $db->prepare($sql);
  $stmt->execute($params);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$row) jsonResponse(false, [], 404, 'Agendamento não encontrado');

  jsonResponse(true, [ $row ], 200, null);

} catch (Throwable $e) {
  error_log('update appointments error: '.$e->getMessage());
  jsonResponse(false, [], 500, 'Falha ao atualizar agendamento');
}
