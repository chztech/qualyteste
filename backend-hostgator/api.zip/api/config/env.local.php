<?php
return [
  'DB_NAME' => 'chztec51_qualycorpore',
  'DB_USER' => 'chztec51_qualycorpore',
  'DB_PASS' => ',[n1cOul?Ijf',
  'JWT_SECRET' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMn0.KMUFsIDTnFmyG3nMiGM6H9FNFUROf3wh7SmqJp-QV30',
  'JWT_EXPIRE_SECONDS' => 3600,
];
