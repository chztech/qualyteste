<?php
return [
  'DB_NAME' => 'chztec51_qualycorpore',
  'DB_USER' => 'chztec51_qualycorpore',
  'DB_PASS' => ',[n1cOul?Ijf',
  'JWT_SECRET' => 'TroqueEstaChavePorUmaMuitoForte!',
  'JWT_EXPIRE_SECONDS' => 3600,
];
